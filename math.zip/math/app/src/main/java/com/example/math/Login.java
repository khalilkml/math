package com.example.math;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {


    /*@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = findViewById(R.id.login);
        login.setOnClickListener(v -> new Intent(Login.this, Login.class));
    }*/
}